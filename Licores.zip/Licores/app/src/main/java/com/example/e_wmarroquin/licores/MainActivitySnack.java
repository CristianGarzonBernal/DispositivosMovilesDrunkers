package com.example.e_wmarroquin.licores;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivitySnack extends AppCompatActivity {
    private RecyclerView recycler1;
    private RecyclerView.Adapter adapter1;
    private RecyclerView.LayoutManager lManager1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_snack);
        List items2 = new ArrayList();

        items2.add(new Snack(R.drawable.papa, "Papas", "papas marca", 1500));
        items2.add(new Snack(R.drawable.jugo, "Jugo", "Jugo marca", 2800));
        items2.add(new Snack(R.drawable.chocolate, "Chocolatina", "chocolatina marca", 2300));
        items2.add(new Snack(R.drawable.galletas, "Galletas", "Galletas marca", 4800));
        items2.add(new Snack(R.drawable.dulces, "Dulces", "Paquete de dulces marca", 5400));

        recycler1 = (RecyclerView) findViewById(R.id.ListaSnacks);
        recycler1.setHasFixedSize(true);

        lManager1 = new LinearLayoutManager(this);
        recycler1.setLayoutManager(lManager1);

        adapter1 = new adaptadorlicores(items2);
        recycler1.setAdapter(adapter1);
    }
}
