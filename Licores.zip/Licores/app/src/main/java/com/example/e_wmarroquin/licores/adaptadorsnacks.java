package com.example.e_wmarroquin.licores;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class adaptadorsnacks extends RecyclerView.Adapter<adaptadorsnacks.SnacksViewHolder> {
    private List<Snack> items2;

    public static class SnacksViewHolder extends RecyclerView.ViewHolder {
        // Campos respectivos de un item
        public ImageView imagenSnack;
        public TextView nombreSnack;
        public TextView descripcionSnack;
        public TextView precioSnack;

        public SnacksViewHolder(View v) {
            super(v);
            imagenSnack = (ImageView) v.findViewById(R.id.imagenSnack);
            nombreSnack = (TextView) v.findViewById(R.id.nombreSnack);
            descripcionSnack = (TextView) v.findViewById(R.id.descripcionSnack);
            precioSnack= (TextView)v.findViewById(R.id.precioSnack);
        }
    }

    public adaptadorsnacks(List<Snack> items2) {
        this.items2 = items2;
    }

    @Override
    public int getItemCount() {
        return items2.size();
    }

    @Override
    public SnacksViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.activity_main_snack, viewGroup, false);
        return new SnacksViewHolder(v);
    }

    @Override
    public void onBindViewHolder(SnacksViewHolder viewHolder, int i) {
        viewHolder.imagenSnack.setImageResource(items2.get(i).getImagenSnack());
        viewHolder.nombreSnack.setText(items2.get(i).getNombreSnack());
        viewHolder.descripcionSnack.setText(items2.get(i).getDescripcionSnack());
        viewHolder.precioSnack.setText("Precio:"+Integer.toString(items2.get(i).getPrecioSnack()));
    }
}