package com.example.e_wmarroquin.licores;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CarroCompras extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carro_compras);
    }
}