package com.example.e_wmarroquin.licores;

public class Snack {
    private int imagenSnack;
    private String nombreSnack;
    private String descripcionSnack;
    private int precioSnack;

    public Snack(int imagenSnack, String nombreSnack, String descripcionSnack, int precioSnack) {
        this.imagenSnack = imagenSnack;
        this.nombreSnack = nombreSnack;
        this.descripcionSnack = descripcionSnack;
        this.precioSnack = precioSnack;
    }

    public int getImagenSnack() {
        return imagenSnack;
    }

    public void setImagenSnack(int imagenSnack) {
        this.imagenSnack = imagenSnack;
    }

    public String getNombreSnack() {
        return nombreSnack;
    }

    public void setNombreSnack(String nombreSnack) {
        this.nombreSnack = nombreSnack;
    }

    public String getDescripcionSnack() {
        return descripcionSnack;
    }

    public void setDescripcionSnack(String descripcionSnack) {
        this.descripcionSnack = descripcionSnack;
    }

    public int getPrecioSnack() {
        return precioSnack;
    }

    public void setPrecioSnack(int precioSnack) {
        this.precioSnack = precioSnack;
    }
}
